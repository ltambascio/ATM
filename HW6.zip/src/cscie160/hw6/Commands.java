package cscie160.hw6;

public enum Commands 
{
    DEPOSIT, WITHDRAW, BALANCE
}
