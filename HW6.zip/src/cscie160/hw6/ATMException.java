package cscie160.hw6;

public class ATMException extends Exception 
{
    public ATMException(String msg) 
	{
		super(msg);
    }
}
