package cscie160.hw4;

public class ATMException extends Exception 
{
    public ATMException(String msg) 
	{
		super(msg);
    }
}
